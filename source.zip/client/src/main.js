import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { Chess } from 'chess.js';
import { io } from 'socket.io-client';
import './style.css';

const $ = (s) => document.querySelector(s);
const chess = new Chess();
const host = $('#chess-canvas');
let scene, camera, renderer, composer, bloomPass, controls, raycaster, pointer;
let boardGroup, piecesGroup, highlightsGroup, atmospherePoints, atmosphereGeometry, atmosphereVelocities = [];
let animatedAccents = [], lastFrameTime = 0;
let selected = null, legalTargets = [], squareMeshes = new Map(), pieceMeshes = new Map();
let socket = null, onlineMode = false, robotMode = false, robotThinking = false, roomCode = null, playerColor = 'w', matchStarted = false;
let robotSearchToken = 0;
let victorySoundPlayed = false;
const victoryAudio = new Audio('/som-vitoria.mp3');
victoryAudio.preload = 'auto';
function playVictorySound(){
  if(victorySoundPlayed) return;
  victorySoundPlayed = true;
  try { victoryAudio.currentTime = 0; const playback = victoryAudio.play(); if (playback?.catch) playback.catch(() => {}); } catch {}
}
const INITIAL_CLOCK_MS = 10 * 60 * 1000;
let clockTimes = { w: INITIAL_CLOCK_MS, b: INITIAL_CLOCK_MS };
let clockActive = 'w', clockLastTick = 0, clockStarted = false, clockInterval = null, clockExpired = false;
let cameraAlt = false, boardFlipped = false, cameraLocked = false, lastToast = 0;
const activeAnimations = [];
const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches || false;
const files = 'abcdefgh';
const pieceNames = { k:'Rei', q:'Dama', r:'Torre', b:'Bispo', n:'Cavalo', p:'Peão' };
const unicodePieces = { wk:'♔', wq:'♕', wr:'♖', wb:'♗', wn:'♘', wp:'♙', bk:'♚', bq:'♛', br:'♜', bb:'♝', bn:'♞', bp:'♟' };
const materials = {
  white: new THREE.MeshPhysicalMaterial({color:0xf3ead8, metalness:.22, roughness:.2, clearcoat:.48, clearcoatRoughness:.18}),
  whiteAccent: new THREE.MeshPhysicalMaterial({color:0xd7b56e, metalness:.88, roughness:.18, clearcoat:.35}),
  black: new THREE.MeshPhysicalMaterial({color:0x171a22, metalness:.48, roughness:.19, clearcoat:.55, clearcoatRoughness:.16}),
  blackAccent: new THREE.MeshPhysicalMaterial({color:0xd8a64d, metalness:.9, roughness:.16, clearcoat:.4}),
  light: new THREE.MeshPhysicalMaterial({color:0xdac7a0, metalness:.12, roughness:.31, clearcoat:.18}),
  dark: new THREE.MeshPhysicalMaterial({color:0x302f35, metalness:.2, roughness:.28, clearcoat:.22}),
  selected: new THREE.MeshBasicMaterial({color:0xffd36b, transparent:true, opacity:.58}),
  target: new THREE.MeshBasicMaterial({color:0x78dfaa, transparent:true, opacity:.7}),
  targetSquare: new THREE.MeshBasicMaterial({color:0x35f0a0, transparent:true, opacity:.22, side:THREE.DoubleSide, depthWrite:false}),
  targetCapture: new THREE.MeshBasicMaterial({color:0xff6b6b, transparent:true, opacity:.25, side:THREE.DoubleSide, depthWrite:false})
};
const pieceGeometryCache = new Map();
const createMat = (color, metalness=.5, roughness=.28) => new THREE.MeshStandardMaterial({color,metalness,roughness});
function materialFor(color, accent=false){ return color==='w' ? (accent?materials.whiteAccent:materials.white) : (accent?materials.blackAccent:materials.black); }
function box(w,h,d,mat, bevel=0){ const geo = bevel ? new THREE.BoxGeometry(w,h,d,1,1,1) : new THREE.BoxGeometry(w,h,d); const mesh=new THREE.Mesh(geo,mat); mesh.castShadow=true;mesh.receiveShadow=true;return mesh; }
function lathe(points, mat, segments=32){const geo=new THREE.LatheGeometry(points.map(([x,y])=>new THREE.Vector2(x,y)),segments);const mesh=new THREE.Mesh(geo,mat);mesh.castShadow=true;mesh.receiveShadow=true;return mesh;}
function addCylinder(group, rTop, rBottom, h, y, mat, seg=32){const m=new THREE.Mesh(new THREE.CylinderGeometry(rTop,rBottom,h,seg),mat);m.position.y=y;m.castShadow=true;m.receiveShadow=true;group.add(m);return m;}
function makePiece(type,color){
  const key=color+type;
  const group=new THREE.Group();
  const base=materialFor(color), accent=materialFor(color,true);
  const addLathe=(profile,mat=base)=>group.add(lathe(profile,mat));
  addLathe([[.0,.04],[.28,.04],[.34,.08],[.35,.13],[.31,.17],[.24,.2],[.19,.28],[.17,.34]]);
  addCylinder(group,.17,.16,.06,.36,accent);
  // Fine machined bands give each piece a crafted, premium finish.
  for (const [radius, y, tube, mat] of [[.285,.105,.012,accent],[.205,.245,.009,accent],[.168,.365,.008,accent]]) {
    const band = new THREE.Mesh(new THREE.TorusGeometry(radius,tube,8,48),mat);
    band.rotation.x=Math.PI/2; band.position.y=y; band.castShadow=true; group.add(band);
  }
  if(type==='p'){
    addLathe([[.12,.39],[.09,.48],[.08,.58],[.12,.65],[.17,.69],[.18,.74],[.15,.79],[.10,.82],[.03,.83],[0,.83]]);
    const head=new THREE.Mesh(new THREE.SphereGeometry(.135,24,20),base);head.position.y=.91;head.castShadow=true;group.add(head);
  } else if(type==='r'){
    addLathe([[.16,.39],[.18,.48],[.2,.58],[.2,.68],[.23,.72],[.24,.78],[.21,.81]]);
    addCylinder(group,.24,.24,.08,.83,accent);
    for(let i=0;i<8;i++){const a=i*Math.PI/4;const mer=box(.085,.13,.09,base);mer.position.set(Math.cos(a)*.19,.91,Math.sin(a)*.19);group.add(mer);}
  } else if(type==='n'){
    addLathe([[.14,.39],[.19,.47],[.16,.56],[.13,.64],[.17,.72],[.22,.78],[.2,.83]]);
    const neck=box(.18,.35,.18,base);neck.position.set(0,.78,0);neck.rotation.z=-.24;group.add(neck);
    const head=box(.21,.23,.2,base);head.position.set(0,.98,.025);head.rotation.z=-.22;group.add(head);
    const muzzle=box(.14,.08,.18,accent);muzzle.position.set(0,.91,.13);group.add(muzzle);
    const ear= new THREE.Mesh(new THREE.ConeGeometry(.065,.16,4),base);ear.position.set(-.07,1.11,0);ear.rotation.z=-.2;group.add(ear);
    const ear2=ear.clone();ear2.position.x=.07;group.add(ear2);
  } else if(type==='b'){
    addLathe([[.15,.39],[.18,.49],[.14,.58],[.1,.67],[.13,.73],[.17,.79],[.14,.84]]);
    const orb=new THREE.Mesh(new THREE.SphereGeometry(.13,24,20),base);orb.position.y=.94;orb.castShadow=true;group.add(orb);
    const cut=box(.035,.18,.035,accent);cut.position.set(.02,.94,.1);cut.rotation.z=.55;group.add(cut);
    const top=new THREE.Mesh(new THREE.SphereGeometry(.045,12,12),accent);top.position.y=1.08;group.add(top);
  } else if(type==='q'){
    addLathe([[.16,.39],[.2,.49],[.16,.58],[.12,.69],[.17,.78],[.2,.84]]);
    addCylinder(group,.19,.17,.05,.84,accent);
    const crown=new THREE.Mesh(new THREE.SphereGeometry(.17,24,20),base);crown.scale.y=.7;crown.position.y=.96;group.add(crown);
    for(let i=0;i<5;i++){const a=i*Math.PI*2/5;const ball=new THREE.Mesh(new THREE.SphereGeometry(.045,12,12),accent);ball.position.set(Math.cos(a)*.13,1.09,Math.sin(a)*.13);group.add(ball);}
  } else if(type==='k'){
    addLathe([[.16,.39],[.2,.5],[.17,.6],[.13,.7],[.18,.79],[.21,.85]]);
    addCylinder(group,.2,.18,.06,.86,accent);
    const orb=new THREE.Mesh(new THREE.SphereGeometry(.14,24,20),base);orb.scale.y=.72;orb.position.y=.97;group.add(orb);
    const vertical=box(.055,.27,.055,accent);vertical.position.y=1.17;group.add(vertical);
    const horizontal=box(.22,.055,.055,accent);horizontal.position.y=1.2;group.add(horizontal);
  }
  group.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;}});
  group.userData={kind:'piece',type,color};
  return group;
}
function initScene(){
  scene=new THREE.Scene();scene.background=new THREE.Color(0x0b0d12);scene.fog=new THREE.Fog(0x0b0d12,15,32);
  camera=new THREE.PerspectiveCamera(38,host.clientWidth/host.clientHeight,.1,100);camera.position.set(7.8,10.8,12.8);
  renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,window.innerWidth<700?1.5:2));renderer.setSize(host.clientWidth,host.clientHeight);
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08;renderer.shadowMap.autoUpdate=true;
  host.appendChild(renderer.domElement);
  controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.06;controls.minDistance=6;controls.maxDistance=22;controls.maxPolarAngle=Math.PI*.48;controls.target.set(0,0,0);controls.enablePan=false;controls.update();
  raycaster=new THREE.Raycaster();pointer=new THREE.Vector2();
  scene.add(new THREE.HemisphereLight(0xc6d7ff,0x27180c,1.65));
  scene.add(new THREE.AmbientLight(0xffffff,.22));
  const keyLight=new THREE.DirectionalLight(0xffd99a,4.2);keyLight.position.set(5,10,5);keyLight.castShadow=true;keyLight.shadow.mapSize.set(window.innerWidth<700?1024:2048,window.innerWidth<700?1024:2048);keyLight.shadow.radius=5;keyLight.shadow.camera.left=-9;keyLight.shadow.camera.right=9;keyLight.shadow.camera.top=9;keyLight.shadow.camera.bottom=-9;keyLight.shadow.bias=-.0004;keyLight.shadow.normalBias=.025;scene.add(keyLight);
  const rim=new THREE.PointLight(0x477dff,24,22,2);rim.position.set(-5,4,-4);scene.add(rim);
  const warm=new THREE.PointLight(0xffa83d,18,18,2);warm.position.set(3,3,5);scene.add(warm);
  boardGroup=new THREE.Group();scene.add(boardGroup);piecesGroup=new THREE.Group();scene.add(piecesGroup);highlightsGroup=new THREE.Group();scene.add(highlightsGroup);
  buildBoard();rebuildPieces();
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(200,200,1,1),new THREE.MeshPhysicalMaterial({color:0x07090e,metalness:.32,roughness:.42,clearcoat:.28,clearcoatRoughness:.4}));floor.rotation.x=-Math.PI/2;floor.position.y=-.42;floor.receiveShadow=true;scene.add(floor);
  // Concentric arena inlays and radial metallic details.
  for(const [radius,tube,color,opacity] of [[5.05,.012,0x8d672d,.62],[5.35,.008,0x45617e,.36],[6.5,.028,0xb98a3c,.8],[6.68,.009,0x4d5a70,.4]]){
    const ring=new THREE.Mesh(new THREE.TorusGeometry(radius,tube,8,192),new THREE.MeshStandardMaterial({color,metalness:.92,roughness:.22,transparent:opacity<1,opacity}));ring.rotation.x=Math.PI/2;ring.position.y=-.34;scene.add(ring);animatedAccents.push({mesh:ring,base:opacity,phase:Math.random()*Math.PI*2});
  }
  // Subtle floating dust catches the rim lights without obscuring the board.
  const particleCount=420, positions=new Float32Array(particleCount*3);atmosphereVelocities=[];
  for(let i=0;i<particleCount;i++){positions[i*3]=(Math.random()-.5)*20;positions[i*3+1]=Math.random()*8-.2;positions[i*3+2]=(Math.random()-.5)*20;atmosphereVelocities.push(.12+Math.random()*.38);}
  atmosphereGeometry=new THREE.BufferGeometry();atmosphereGeometry.setAttribute('position',new THREE.BufferAttribute(positions,3));
  atmospherePoints=new THREE.Points(atmosphereGeometry,new THREE.PointsMaterial({color:0xd9c49a,size:.028,transparent:true,opacity:.46,depthWrite:false,sizeAttenuation:true}));scene.add(atmospherePoints);
  composer=new EffectComposer(renderer);composer.addPass(new RenderPass(scene,camera));
  bloomPass=new UnrealBloomPass(new THREE.Vector2(host.clientWidth,host.clientHeight),window.innerWidth<700?.22:.32,.55,.82);composer.addPass(bloomPass);composer.addPass(new OutputPass());
  renderer.domElement.addEventListener('pointerdown',onBoardPointerDown);
  renderer.domElement.addEventListener('pointermove',onBoardPointerMove);
  renderer.domElement.addEventListener('pointerup',onBoardPointerUp);
  renderer.domElement.addEventListener('pointercancel',onBoardPointerCancel);
  window.addEventListener('resize',resize);
  $('#board-loading').classList.add('hidden');
  animate();
}
function buildBoard(){
  const base=box(8.65,.32,8.65,new THREE.MeshPhysicalMaterial({color:0x17191f,metalness:.62,roughness:.24,clearcoat:.35,clearcoatRoughness:.22}));base.position.y=-.22;boardGroup.add(base);
  const trimMat=new THREE.MeshPhysicalMaterial({color:0xb98a3c,metalness:1,roughness:.16,clearcoat:1,clearcoatRoughness:.08});
  const trim=new THREE.Mesh(new RoundedBoxGeometry(8.78,.09,8.78,4,.035),trimMat);trim.position.y=-.07;boardGroup.add(trim);
  const trimInner=new THREE.Mesh(new RoundedBoxGeometry(8.58,.025,8.58,3,.012),new THREE.MeshStandardMaterial({color:0x17191f,metalness:.72,roughness:.22}));trimInner.position.y=-.008;boardGroup.add(trimInner);
  const inner=box(8.5,.12,8.5,createMat(0x201d19,.35,.35));inner.position.y=-.005;boardGroup.add(inner);
  for(let r=0;r<8;r++)for(let c=0;c<8;c++){
    const light=(r+c)%2===0;
    const tile=new THREE.Mesh(new RoundedBoxGeometry(.992,.095,.992,3,.025),light?materials.light:materials.dark);tile.castShadow=true;tile.receiveShadow=true;tile.position.set(c-3.5,.075,r-3.5);tile.userData={kind:'square',square:files[c]+(8-r),row:r,col:c};boardGroup.add(tile);squareMeshes.set(tile.userData.square,tile);
    const inset=new THREE.Mesh(new RoundedBoxGeometry(.955,.009,.955,2,.018),new THREE.MeshPhysicalMaterial({color:light?0xe6d5b4:0x45434a,metalness:.22,roughness:.3,clearcoat:.45}));inset.position.set(c-3.5,.127,r-3.5);boardGroup.add(inset);
  }
  // Gold corner details and edge markers
  for(const [x,z] of [[-4.24,-4.24],[4.24,-4.24],[-4.24,4.24],[4.24,4.24]]){
    const stud=new THREE.Mesh(new THREE.SphereGeometry(.075,16,12),materials.blackAccent);stud.position.set(x,.02,z);boardGroup.add(stud);
  }
}
function squarePosition(square){const col=files.indexOf(square[0]),row=8-Number(square[1]);return new THREE.Vector3(col-3.5,.14,row-3.5);}
function rebuildPieces(){
  while(piecesGroup.children.length)piecesGroup.remove(piecesGroup.children[0]);
  pieceMeshes.clear();
  const board=chess.board();
  for(let r=0;r<8;r++)for(let c=0;c<8;c++){
    const p=board[r][c];if(!p)continue;
    const square=files[c]+(8-r),mesh=makePiece(p.type,p.color),pos=squarePosition(square);
    mesh.position.set(pos.x,.13,pos.z);mesh.userData.kind='piece';mesh.userData.square=square;piecesGroup.add(mesh);pieceMeshes.set(square,mesh);
  }
  updateHighlights();updateGameUI();
}
function clearGroup(group){while(group.children.length)group.remove(group.children[0]);}
function updateHighlights(){
  clearGroup(highlightsGroup);
  if(selected){
    const p=squarePosition(selected);const m=new THREE.Mesh(new THREE.PlaneGeometry(.88,.88),materials.selected);m.rotation.x=-Math.PI/2;m.position.set(p.x,.142,p.z);highlightsGroup.add(m);
  }
  for(const target of legalTargets){
    const p=squarePosition(target.to);
    // Toda casa legal recebe um brilho translúcido para delimitar claramente o alcance da peça.
    const tileGlow=new THREE.Mesh(new THREE.PlaneGeometry(.94,.94),target.captured?materials.targetCapture:materials.targetSquare);
    tileGlow.rotation.x=-Math.PI/2;tileGlow.position.set(p.x,.151,p.z);
    tileGlow.userData={kind:'target-square-glow',phase:Math.random()*Math.PI*2,baseOpacity:target.captured?.25:.22};highlightsGroup.add(tileGlow);
    // Contorno luminoso e marcador central mantêm a leitura clara em tabuleiros claros e escuros.
    const outline=new THREE.Mesh(new THREE.EdgesGeometry(new THREE.BoxGeometry(.92,.012,.92)),new THREE.LineBasicMaterial({color:target.captured?0xff7777:0x8dffd0,transparent:true,opacity:.95}));
    outline.position.set(p.x,.17,p.z);outline.userData={kind:'target-outline',phase:Math.random()*Math.PI*2};highlightsGroup.add(outline);
    const geo=target.captured?new THREE.TorusGeometry(.31,.035,8,40):new THREE.RingGeometry(.075,.12,32);
    const m=new THREE.Mesh(geo,materials.target);m.rotation.x=-Math.PI/2;m.position.set(p.x,.178,p.z);m.userData={kind:'target-marker',phase:Math.random()*Math.PI*2};highlightsGroup.add(m);
  }
}
let pointerDownPos=null, pointerMoved=false, pointerStartTime=0, pendingSquare=null;

function getSquareFromEvent(e){
  if(!renderer||!camera)return null;
  const rect=renderer.domElement.getBoundingClientRect();
  if(rect.width<1||rect.height<1)return null;
  const x=((e.clientX-rect.left)/rect.width)*2-1;
  const y=-((e.clientY-rect.top)/rect.height)*2+1;
  pointer.set(x,y);
  raycaster.setFromCamera(pointer,camera);
  const hits=raycaster.intersectObjects([...piecesGroup.children,...boardGroup.children],true);
  if(!hits.length)return null;
  let obj=hits[0].object;
  while(obj.parent && obj.userData.kind!=='piece' && obj.userData.kind!=='square'){
    obj=obj.parent;
  }
  if(obj.userData.kind==='piece' || obj.userData.kind==='square'){
    return obj.userData.square || null;
  }
  return null;
}

function onBoardPointerDown(e){
  // Só botão esquerdo / toque principal
  if(e.pointerType==='mouse' && e.button!==0)return;
  pointerDownPos={x:e.clientX,y:e.clientY};
  pointerMoved=false;
  pointerStartTime=performance.now();
  pendingSquare=getSquareFromEvent(e);
  // Se tocou em peça/casa, trava a rotação da câmera para não "roubar" o toque
  if(pendingSquare && controls){
    controls.enableRotate=false;
  }
}

function onBoardPointerMove(e){
  if(!pointerDownPos)return;
  const dx=e.clientX-pointerDownPos.x;
  const dy=e.clientY-pointerDownPos.y;
  // Limite maior para telas de alta densidade (celular)
  if(Math.hypot(dx,dy)>18) pointerMoved=true;
}

function onBoardPointerUp(e){
  if(!pointerDownPos)return;
  const elapsed=performance.now()-pointerStartTime;
  const wasTap=!pointerMoved && elapsed<500;
  const square=pendingSquare || getSquareFromEvent(e);
  pointerDownPos=null;
  pendingSquare=null;
  if(controls) controls.enableRotate=true;
  if(!wasTap || !square)return;
  handleSquare(square);
}

function onBoardPointerCancel(){
  pointerDownPos=null;
  pendingSquare=null;
  if(controls) controls.enableRotate=true;
}
function handleSquare(square){
  if(clockExpired){toast('O tempo acabou. Inicie uma nova partida.');return;}
  if(robotMode && (chess.turn()==='b' || robotThinking)){toast('O robô está pensando…');return;}
  if(onlineMode && socket && matchStarted && chess.turn()!==playerColor){toast('Aguarde a vez do seu oponente.');return;}
  const piece=chess.get(square);
  if(selected){
    const move=legalTargets.find(m=>m.to===square);
    if(move){makeMove(selected,square,move.promotion||'q');return;}
    if(piece&&piece.color===chess.turn()){selected=square;legalTargets=chess.moves({square,verbose:true});updateHighlights();$('#board-hint').textContent=`${pieceNames[piece.type]} selecionado · escolha o destino`;return;}
    selected=null;legalTargets=[];updateHighlights();$('#board-hint').textContent='Selecione uma peça para ver os movimentos possíveis';return;
  }
  if(piece&&piece.color===chess.turn()){
    selected=square;legalTargets=chess.moves({square,verbose:true});updateHighlights();
    $('#board-hint').textContent=`${pieceNames[piece.type]} selecionado · ${legalTargets.length} movimento(s) possível(is)`;
  }else if(piece){toast('Essa peça pertence ao outro lado.');}
}
function makeMove(from,to,promotion='q'){
  try{
    if(clockExpired){toast('O tempo acabou. Inicie uma nova partida.');return;}
    if(!clockStarted)startClock();
    const sourceMesh=pieceMeshes.get(from);
    const movingClone=(!reducedMotion && sourceMesh) ? sourceMesh.clone(true) : null;
    const startPosition=sourceMesh ? sourceMesh.position.clone() : null;
    const move=chess.move({from,to,promotion});
    if(!move)return;
    selected=null;legalTargets=[];rebuildPieces();
    if(movingClone && startPosition){
      const end=squarePosition(to);movingClone.position.copy(startPosition);movingClone.userData.kind='animation';
      scene.add(movingClone);const destination=pieceMeshes.get(to);if(destination)destination.visible=false;
      activeAnimations.push({mesh:movingClone,from:startPosition,to:new THREE.Vector3(end.x,.13,end.z),started:performance.now(),duration:860,destination});
    }
    addMoveToHistory(move);
    switchClockAfterMove();
    if(chess.isGameOver())stopClock();
    if(chess.isCheckmate())playVictorySound();
    if(onlineMode&&socket&&matchStarted)socket.emit('game:move',{roomCode,move:{from,to,promotion}});
    if(chess.isGameOver())toast(gameOverMessage());
    else $('#board-hint').textContent=`${move.san} · ${chess.turn()==='w'?'Brancas':'Pretas'} jogam agora`;
    if(robotMode && !chess.isGameOver() && chess.turn()==='b') scheduleRobotMove();
  }catch(err){toast('Movimento inválido.');}
}
function addMoveToHistory(move){
  const container=$('#move-history');
  if(container.querySelector('.empty-history'))container.innerHTML='';
  const history=chess.history({verbose:true});
  container.innerHTML='';
  for(let i=0;i<history.length;i+=2){
    const line=document.createElement('div');line.className='move-line';
    const num=document.createElement('span');num.className='move-num';num.textContent=String(i/2+1)+'.';
    const white=document.createElement('span');white.className='move-white';white.textContent=history[i]?.san||'';
    const black=document.createElement('span');black.className='move-black';black.textContent=history[i+1]?.san||'';
    line.append(num,white,black);container.append(line);
  }
  container.scrollTop=container.scrollHeight;
}
function formatClock(ms){const total=Math.max(0,Math.ceil(ms/1000));return `${Math.floor(total/60)}:${String(total%60).padStart(2,'0')}`;}
function renderClocks(){
  for(const color of ['w','b']){const card=$(`#${color==='w'?'white':'black'}-clock-card`),display=$(`#${color==='w'?'white':'black'}-clock`);if(!card||!display)continue;display.textContent=formatClock(clockTimes[color]);card.classList.toggle('active',clockStarted&&!clockExpired&&clockActive===color);card.classList.toggle('low-time',clockTimes[color]<=60000);card.classList.toggle('flagged',clockTimes[color]===0);}
  const legacy=$('#clock');if(legacy)legacy.innerHTML=`${formatClock(clockTimes.w)} <small>/ ${formatClock(clockTimes.b)}</small>`;
}
function stopClock(){if(clockInterval!==null){clearInterval(clockInterval);clockInterval=null;}}
function resetClock(){stopClock();clockTimes={w:INITIAL_CLOCK_MS,b:INITIAL_CLOCK_MS};clockActive='w';clockLastTick=0;clockStarted=false;clockExpired=false;renderClocks();}
function tickClock(){if(!clockStarted||clockExpired||chess.isGameOver())return;const now=Date.now();if(clockLastTick){clockTimes[clockActive]=Math.max(0,clockTimes[clockActive]-(now-clockLastTick));}clockLastTick=now;renderClocks();if(clockTimes[clockActive]===0){clockExpired=true;stopClock();$('#game-status').textContent=`Tempo esgotado · ${clockActive==='w'?'Pretas':'Brancas'} venceram`;$('#board-hint').textContent='Tempo esgotado';toast(`Tempo esgotado! ${clockActive==='w'?'Pretas':'Brancas'} venceram.`);playVictorySound();}}
function startClock(){if(clockStarted||clockExpired)return;clockStarted=true;clockActive=chess.turn();clockLastTick=Date.now();clockInterval=window.setInterval(tickClock,200);renderClocks();}
function switchClockAfterMove(){if(clockExpired)return;tickClock();if(!clockExpired){clockActive=chess.turn();clockLastTick=Date.now();renderClocks();}}
function updateGameUI(){
  $('#turn-label').textContent=chess.turn()==='w'?'Brancas':'Pretas';$('#turn-piece').textContent=chess.turn()==='w'?'♙':'♟';
  $('#move-count').textContent=Math.ceil(chess.history().length/2);
  $('#game-status').textContent=clockExpired?`Tempo esgotado · ${clockActive==='w'?'Pretas':'Brancas'} venceram`:chess.isCheckmate()?'Xeque-mate':chess.isDraw()?'Empate':chess.isCheck()?'Xeque':'Em andamento';
  $('#undo-move').disabled=chess.history().length===0;renderClocks();
}
function gameOverMessage(){if(chess.isCheckmate())return `Xeque-mate! ${chess.turn()==='w'?'Pretas':'Brancas'} venceram.`;if(chess.isDraw())return 'A partida terminou empatada.';return 'Fim de partida.'}
function newGame(){robotSearchToken++;robotThinking=false;victorySoundPlayed=false;resetClock();chess.reset();selected=null;legalTargets=[];$('#move-history').innerHTML='<div class="empty-history"><span>♟</span><p>Seus movimentos aparecerão aqui.</p></div>';rebuildPieces();$('#board-hint').textContent=robotMode?'Nova partida contra o robô · você joga de brancas':'Nova partida iniciada';if(robotMode){$('#opponent-name').textContent='Robô WorldX';$('#opponent-status').textContent=robotLevelLabel();}}
const BOT_VALUES={p:100,n:320,b:335,r:500,q:900,k:20000};
const BOT_LEVELS={amateur:{depth:1,blunder:0.24,think:550},intermediate:{depth:2,blunder:0.07,think:850},professional:{depth:3,blunder:0.015,think:1100}};
function robotLevelLabel(){return ({amateur:'Amador · Fácil',intermediate:'Intermediário · Médio',professional:'Profissional · Difícil'})[$('#robot-level')?.value||'intermediate'];}
function evaluatePosition(game){
  const board=game.board();let score=0, phase=0;
  for(let r=0;r<8;r++)for(let c=0;c<8;c++){const p=board[r][c];if(!p)continue;const sign=p.color==='w'?1:-1;let value=BOT_VALUES[p.type]||0;const center=3.5-(Math.abs(3.5-c)+Math.abs(3.5-r))/2;
    if(p.type==='p')value+=((p.color==='w'?6-r:r-1)*7)+center*3;
    else if(p.type==='n')value+=center*12;
    else if(p.type==='b')value+=center*6;
    else if(p.type==='q')value+=center*2;
    if(p.type!=='p'&&p.type!=='k')value+=center*2;
    score+=sign*value;phase+=p.type==='q'?4:p.type==='r'?2:p.type==='b'||p.type==='n'?1:0;
  }
  const side=game.turn()==='w'?1:-1;
  let mobility=0;try{mobility=game.moves().length;}catch{}
  return score*side+Math.min(mobility,40)*1.4;
}
function moveOrderScore(move){return (move.captured?(BOT_VALUES[move.captured]||0)*10-(BOT_VALUES[move.piece]||0):0)+(move.promotion?(BOT_VALUES[move.promotion]||0):0)+(move.san?.includes('+')?35:0)+(move.san?.includes('#')?100000:0);}
function minimax(game,depth,alpha,beta,ply=0){
  if(game.isCheckmate())return -100000+ply;
  if(game.isDraw()||game.isStalemate()||game.isThreefoldRepetition()||game.isInsufficientMaterial())return 0;
  if(depth<=0)return evaluatePosition(game);
  const moves=game.moves({verbose:true}).sort((a,b)=>moveOrderScore(b)-moveOrderScore(a));
  if(!moves.length)return evaluatePosition(game);
  let best=-Infinity;
  for(const m of moves){game.move({from:m.from,to:m.to,promotion:m.promotion||'q'});const value=-minimax(game,depth-1,-beta,-alpha,ply+1);game.undo();if(value>best)best=value;if(value>alpha)alpha=value;if(alpha>=beta)break;}
  return best;
}
function chooseRobotMove(){
  const level=BOT_LEVELS[$('#robot-level').value]||BOT_LEVELS.intermediate;
  const game=new Chess(chess.fen());const moves=game.moves({verbose:true});if(!moves.length)return null;
  // Easy mode deliberately makes occasional human-like suboptimal choices.
  if(level.blunder>0&&Math.random()<level.blunder){const shuffled=moves.slice().sort(()=>Math.random()-.5);return shuffled[Math.floor(Math.random()*Math.min(5,shuffled.length))];}
  let best=-Infinity,bestMoves=[];const ordered=moves.sort((a,b)=>moveOrderScore(b)-moveOrderScore(a));
  for(const m of ordered){game.move({from:m.from,to:m.to,promotion:m.promotion||'q'});const score=-minimax(game,level.depth-1,-Infinity,Infinity,1);game.undo();if(score>best){best=score;bestMoves=[m];}else if(score===best)bestMoves.push(m);}
  return bestMoves[Math.floor(Math.random()*bestMoves.length)]||moves[0];
}
function scheduleRobotMove(){
  if(!robotMode||robotThinking||chess.isGameOver()||chess.turn()!=='b')return;
  robotThinking=true;const token=++robotSearchToken;$('#opponent-status').textContent='Analisando jogadas…';$('#game-status').textContent='Robô pensando';$('#board-hint').textContent='O Robô WorldX está calculando a melhor jogada…';
  const level=BOT_LEVELS[$('#robot-level').value]||BOT_LEVELS.intermediate;
  window.setTimeout(()=>{if(token!==robotSearchToken||!robotMode||chess.isGameOver()||chess.turn()!=='b'){robotThinking=false;return;}
    let move;try{move=chooseRobotMove();}catch(err){console.error('Falha na IA de xadrez:',err);}
    if(token!==robotSearchToken)return;robotThinking=false;
    if(move){makeMove(move.from,move.to,move.promotion||'q');$('#opponent-status').textContent=robotLevelLabel();}
    if(!chess.isGameOver())$('#board-hint').textContent='Sua vez · escolha uma peça';
  },level.think);
}
function resize(){
  if(!renderer||!camera)return;
  const w=host.clientWidth,h=host.clientHeight;
  if(w<1||h<1)return;
  camera.aspect=w/h;
  // Em telas altas (celular em pé / tela cheia) aumenta o FOV e afasta um pouco a câmera
  // para o tabuleiro inteiro aparecer sem cortar as bordas.
  const aspect=w/h;
  if(aspect<0.75){ // portrait bem estreito
    camera.fov=48;
    if(!cameraLocked){camera.position.set(0,12.5,14.5);controls.target.set(0,0,0);}
  }else if(aspect<1.05){ // quase quadrado / portrait
    camera.fov=44;
    if(!cameraLocked){camera.position.set(5.5,11.5,13.2);controls.target.set(0,0,0);}
  }else{
    camera.fov=38;
  }
  camera.updateProjectionMatrix();
  controls.update();
  renderer.setSize(w,h);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,window.innerWidth<700?1.5:2));
  if(composer)composer.setSize(w,h);
  if(bloomPass)bloomPass.setSize(w,h);
}
function animate(){
  requestAnimationFrame(animate);if(controls)controls.update();
  const now=performance.now(), dt=Math.min(.05,(now-lastFrameTime)/1000||.016);lastFrameTime=now;
  if(atmospherePoints){const attr=atmosphereGeometry.attributes.position;for(let i=0;i<atmosphereVelocities.length;i++){const j=i*3+1;attr.array[j]+=atmosphereVelocities[i]*dt;if(attr.array[j]>7.8){attr.array[j]=-.25;attr.array[i*3]=(Math.random()-.5)*20;attr.array[i*3+2]=(Math.random()-.5)*20;}}attr.needsUpdate=true;atmospherePoints.rotation.y+=dt*.008;}
  for(const a of animatedAccents){a.mesh.material.opacity=a.base*(.82+.18*Math.sin(now*.0007+a.phase));}
  if(highlightsGroup)for(const marker of highlightsGroup.children){if(marker.userData.kind==='target-marker'){const pulse=.92+.12*Math.sin(now*.004+marker.userData.phase);marker.scale.setScalar(pulse);}
    else if(marker.userData.kind==='target-square-glow'){marker.material.opacity=marker.userData.baseOpacity+.08*(.5+.5*Math.sin(now*.0035+marker.userData.phase));}
    else if(marker.userData.kind==='target-outline'){marker.material.opacity=.62+.35*(.5+.5*Math.sin(now*.004+marker.userData.phase));}}
  for(let i=activeAnimations.length-1;i>=0;i--){const a=activeAnimations[i],t=Math.min(1,(now-a.started)/a.duration),eased=1-Math.pow(1-t,3);a.mesh.position.set(a.from.x+(a.to.x-a.from.x)*eased,a.from.y+(a.to.y-a.from.y)*eased+Math.sin(Math.PI*t)*.22,a.from.z+(a.to.z-a.from.z)*eased);a.mesh.rotation.y+=.012;if(t>=1){scene.remove(a.mesh);if(a.destination)a.destination.visible=true;activeAnimations.splice(i,1);}}
  if(renderer&&scene&&camera){if(composer)composer.render();else renderer.render(scene,camera);}
}
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(lastToast);lastToast=setTimeout(()=>el.classList.remove('show'),2800);}
function updateFullscreenButton(){
  const button=$('#arena-fullscreen');
  if(!button)return;
  const active=document.fullscreenElement===$('.arena');
  button.setAttribute('aria-pressed',String(active));
  button.title=active?'Sair da tela cheia':'Abrir arena em tela cheia';
  button.innerHTML=active?'⛶ <span class="fullscreen-label">Sair da tela cheia</span>':'⛶ <span class="fullscreen-label">Tela cheia</span>';
  requestAnimationFrame(()=>resize());
}
async function toggleArenaFullscreen(){
  const arena=$('.arena');
  try{
    if(document.fullscreenElement){await document.exitFullscreen();}
    else if(arena.requestFullscreen){await arena.requestFullscreen();}
    else {arena.classList.toggle('fullscreen-fallback');}
    updateFullscreenButton();
  }catch(error){
    arena.classList.toggle('fullscreen-fallback');
    updateFullscreenButton();
    toast(arena.classList.contains('fullscreen-fallback')?'Modo de tela ampliada ativado.':'Não foi possível abrir a tela cheia neste navegador.');
  }
}
function setCameraLocked(locked){
  cameraLocked=locked;
  if(controls)controls.enabled=!locked;
  const button=$('#camera-lock'),state=$('#camera-state');
  button.setAttribute('aria-pressed',String(locked));
  button.classList.toggle('is-locked',locked);
  button.title=locked?'Câmera travada. Toque para liberar a movimentação da câmera.':'Travar a câmera para mover peças sem girar a visão';
  button.innerHTML=locked?'<span class="lock-symbol" aria-hidden="true">🔓</span> <span class="lock-label">Câmera travada</span>':'<span class="lock-symbol" aria-hidden="true">🔒</span> <span class="lock-label">Travar câmera</span>';
  state.classList.toggle('is-locked',locked);
  state.innerHTML=locked?'<span class="camera-state-icon" aria-hidden="true">🔒</span><span>CÂMERA TRAVADA · MOVER PEÇAS LIVREMENTE</span>':'<span class="camera-state-icon" aria-hidden="true">↻</span><span>CÂMERA LIVRE</span>';
  if($('#board-hint'))$('#board-hint').textContent=locked?'Câmera travada · selecione e mova as peças sem girar a visão':'Câmera livre · arraste para girar a visão; toque nas peças para jogar';
  toast(locked?'Câmera travada. Agora você pode mover as peças sem mexer na visão.':'Câmera liberada. Você pode girar e aproximar o tabuleiro.');
}
function resetCamera(){camera.position.set(7.8,10.8,12.8);controls.target.set(0,0,0);controls.update();}
function flipBoard(){boardFlipped=!boardFlipped;camera.position.set(boardFlipped?-7.8:7.8,10.8,boardFlipped?-12.8:12.8);controls.target.set(0,0,0);controls.update();}
function randomCode(){return 'WX'+Math.random().toString(36).slice(2,6).toUpperCase();}
function openRoomDialog(mode){$('#dialog-title').textContent=mode==='create'?'Criar uma sala':'Entrar em uma sala';$('#dialog-description').textContent=mode==='create'?'Gere um código e compartilhe com seu oponente.':'Digite o código recebido do seu oponente.';$('#room-code').value=mode==='create'?randomCode():'';$('#room-dialog').dataset.mode=mode;$('#room-dialog').showModal();}
function setupSocket(){
  const url=import.meta.env.VITE_GAME_SERVER_URL;
  if(!url){$('#connection-title').textContent='Servidor não configurado';$('#connection-detail').textContent='Jogue localmente ou configure o backend';return;}
  socket=io(url,{transports:['websocket','polling'],timeout:8000});
  socket.on('connect',()=>{$('#connection-title').textContent='Servidor conectado';$('#connection-detail').textContent='Pronto para entrar em uma sala';toast('Conexão multiplayer estabelecida.');});
  socket.on('connect_error',()=>{$('#connection-title').textContent='Servidor indisponível';$('#connection-detail').textContent='Verifique a URL do servidor';});
  socket.on('room:created',({roomCode:code,color})=>{roomCode=code;playerColor=color;matchStarted=true;$('#room-code').value=code;$('#opponent-status').textContent='Sala criada · aguardando';toast(`Sala ${code} criada. Compartilhe o código!`);});
  socket.on('room:joined',({roomCode:code,color,fen})=>{roomCode=code;playerColor=color;matchStarted=true;if(fen)chess.load(fen);rebuildPieces();$('#opponent-status').textContent='Conectado';$('#room-dialog').close();toast(`Você entrou na sala ${code}.`);});
  socket.on('game:ready',({fen})=>{matchStarted=true;if(fen)chess.load(fen);rebuildPieces();$('#opponent-status').textContent='Conectado';toast('O oponente entrou. Boa partida!');});
  socket.on('game:move',({fen})=>{if(fen && chess.fen()!==fen){chess.load(fen);selected=null;legalTargets=[];rebuildPieces();addMoveToHistory();}});
  socket.on('room:error',({message})=>toast(message||'Não foi possível entrar na sala.'));
  socket.on('chat:message',({name,message})=>appendChat(name,message));
}
function appendChat(name,message){const p=document.createElement('p'),b=document.createElement('b'),span=document.createElement('span');b.textContent=name;span.textContent=message;p.append(b,span);$('#chat-messages').append(p);$('#chat-messages').scrollTop=$('#chat-messages').scrollHeight;}
function wireUI(){
  $('#new-game').addEventListener('click',()=>{if(onlineMode&&matchStarted){toast('Em uma partida online, solicite uma nova sala.');return;}newGame();});
  $('#undo-move').addEventListener('click',()=>{if(onlineMode&&matchStarted){toast('Desfazer está desativado durante partidas online.');return;}robotSearchToken++;robotThinking=false;let undone=false;if(chess.undo())undone=true;if(robotMode&&chess.history().length&&chess.turn()==='b'){chess.undo();}if(undone){selected=null;legalTargets=[];rebuildPieces();addMoveToHistory();$('#board-hint').textContent='Movimento desfeito';}});
  $('#reset-view').addEventListener('click',resetCamera);$('#flip-board').addEventListener('click',flipBoard);
  $('#camera-lock').addEventListener('click',()=>setCameraLocked(!cameraLocked));
  $('#arena-fullscreen').addEventListener('click',toggleArenaFullscreen);
  document.addEventListener('fullscreenchange',()=>{updateFullscreenButton();setTimeout(resize,80);});
  window.addEventListener('orientationchange',()=>setTimeout(resize,150));
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&clockStarted&&!clockExpired)tickClock();});
  window.addEventListener('resize',()=>requestAnimationFrame(resize));
  $('#camera-toggle').addEventListener('click',()=>{cameraAlt=!cameraAlt;camera.position.set(cameraAlt?0:7.8,cameraAlt?15:10.8,cameraAlt?14:12.8);controls.update();});
  $('#quick-match').addEventListener('click',()=>{if(!onlineMode){toast('Para jogar contra a IA, use o tabuleiro abaixo. Para partidas online, selecione Online.');return;}if(!socket){toast('Configure VITE_GAME_SERVER_URL para jogar online.');return;}socket.emit('match:quick');toast('Procurando um oponente…');});
  $('#create-room').addEventListener('click',()=>openRoomDialog('create'));$('#join-room').addEventListener('click',()=>openRoomDialog('join'));
  $('#generate-code').addEventListener('click',()=>$('#room-code').value=randomCode());
  $('#confirm-room').addEventListener('click',()=>{
    const code=$('#room-code').value.trim().toUpperCase();if(!code){toast('Informe um código de sala.');return;}
    if(!socket){toast('Configure o servidor multiplayer primeiro.');return;}
    if($('#room-dialog').dataset.mode==='create')socket.emit('room:create',{roomCode:code});
    else socket.emit('room:join',{roomCode:code});
    toast('Conectando à sala…');
  });
  document.querySelectorAll('.mode').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.mode').forEach(b=>b.classList.remove('active'));btn.classList.add('active');const mode=btn.dataset.mode;onlineMode=mode==='online';robotMode=mode==='robot';matchStarted=false;robotSearchToken++;robotThinking=false;$('#difficulty-wrap').hidden=!robotMode;if(robotMode){$('#connection-title').textContent='Robô IA pronto';$('#connection-detail').textContent='Jogue offline contra a inteligência artificial';$('#opponent-name').textContent='Robô WorldX';$('#opponent-status').textContent=robotLevelLabel();$('#opponent-rating').innerHTML='IA <small>CPU</small>';newGame();toast('Modo contra robô ativado. Você joga com as brancas.');}else if(mode==='local'){ $('#connection-title').textContent='Modo local pronto';$('#connection-detail').textContent='Partida local no mesmo dispositivo';$('#opponent-name').textContent='Oponente';$('#opponent-status').textContent='Jogador local';$('#opponent-rating').innerHTML='1200 <small>PTS</small>';newGame();toast('Modo local ativado.');}else{$('#connection-title').textContent=socket&&socket.connected?'Servidor conectado':'Servidor não configurado';$('#connection-detail').textContent='Conecte ao servidor para jogar online';$('#opponent-name').textContent='Oponente';$('#opponent-status').textContent='Aguardando conexão';$('#opponent-rating').innerHTML='1200 <small>PTS</small>';toast('Modo online selecionado.');}}));
  $('#robot-level').addEventListener('change',()=>{const descriptions={amateur:'Jogadas mais simples e erros ocasionais para aprender.',intermediate:'Busca tática equilibrada para desafiar sua estratégia.',professional:'Busca mais profunda, priorizando material, centro e táticas.'};$('#robot-description').textContent=descriptions[$('#robot-level').value];$('#opponent-status').textContent=robotLevelLabel();if(robotMode){newGame();toast('Nível do robô atualizado.');}});
  document.querySelectorAll('.nav-item').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.nav-item').forEach(b=>b.classList.remove('active'));btn.classList.add('active');if(btn.dataset.nav!=='jogar')toast(`${btn.textContent.trim()} estará disponível em uma próxima etapa.`);}));
  $('#chat-form').addEventListener('submit',e=>{e.preventDefault();const input=$('#chat-input'),message=input.value.trim();if(!message)return;if(onlineMode&&socket&&roomCode)socket.emit('chat:message',{roomCode,message});else appendChat('Você',message);input.value='';});
}
wireUI();setupSocket();initScene();
