# WorldXadrez App

Jogo de xadrez 3D — funciona offline (local + robô) e online (multiplayer).

## Como gerar o APK pelo celular

1. Crie um repositório novo no GitHub chamado `worldxadrez-app` (deixe Public)
2. Faça upload do arquivo `source.zip` (só esse arquivo)
3. Vá em Actions e espere o workflow "Build APK" ficar verde
4. Baixe o APK em Artifacts → worldxadrez-apk
5. Instale no celular
