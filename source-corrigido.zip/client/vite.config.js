import { defineConfig } from 'vite';

export default defineConfig({
  // Caminhos relativos permitem que o app carregue os arquivos locais dentro do APK.
  base: './',
  build: {
    outDir: 'dist',
    emptyOutDir: true,
  },
});
